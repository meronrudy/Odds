<template>
  <TopSoccer />
  <SoccerLive />
  <UpCmingSoccer />
</template>

<script setup lang="ts">
import SoccerLive from "../components/Pages/Soccer/SoccerLive.vue";
import TopSoccer from "../components/Pages/Soccer/TopSoccer.vue";
import UpCmingSoccer from "../components/Pages/Soccer/UpCmingSoccer.vue";
</script>

<style scoped></style>

<template>
  <TopFloorball />
  <FloorballLive />
  <UpCmingFloorball />
</template>

<script setup lang="ts">
import FloorballLive from "../components/Pages/Floorball/FloorballLive.vue";
import TopFloorball from "../components/Pages/Floorball/TopFloorball.vue";
import UpCmingFloorball from "../components/Pages/Floorball/UpCmingFloorball.vue";
</script>

<style scoped></style>

<template>
  <div>
    <TopBoxing />
    <UpCmingBoxing />
  </div>
</template>

<script setup lang="ts">
import TopBoxing from "../components/Pages/Boxing/TopBoxing.vue";
import UpCmingBoxing from "../components/Pages/Boxing/UpCmingBoxing.vue";
</script>

<style scoped></style>

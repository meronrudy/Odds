<template>
<TopEShooter />
<UpCmingEshooter/>
</template>

<script setup lang="ts">
import TopEShooter from '../components/Pages/eShooter/TopEShooter.vue';
import UpCmingEshooter from '../components/Pages/eShooter/UpCmingEshooter.vue';
</script>

<style scoped></style>

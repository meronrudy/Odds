<template>
  <TopRugby />
  <UpcmingRugby/>
</template>

<script setup lang="ts">
import TopRugby from '../components/Pages/Rugby/TopRugby.vue';
import UpcmingRugby from '../components/Pages/Rugby/UpcmingRugby.vue';
</script>

<style scoped></style>


<template>
  <TopCricket />
  <CricketLive />
  <UpComming />
</template>

<script setup lang="ts">
import CricketLive from '../components/Pages/Cricket/CricketLive.vue';
import TopCricket from '../components/Pages/Cricket/TopCricket.vue';
import UpComming from '../components/Pages/Cricket/UpComming.vue';
</script>

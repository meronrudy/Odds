<template>
  <TopMma />
  <UpCmingMma />
</template>

<script setup lang="ts">
import TopMma from "../components/Pages/Mma/TopMma.vue";
import UpCmingMma from "../components/Pages/Mma/UpCmingMma.vue";
</script>

<style scoped></style>

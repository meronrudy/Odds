<template>
  <div>
    <TopRocketLeague />
    <UpCmingErocketLeague />
  </div>
</template>

<script setup lang="ts">
import TopRocketLeague from "../components/Pages/eRocketLeague/TopRocketLeague.vue";
import UpCmingErocketLeague from "../components/Pages/eRocketLeague/UpCmingErocketLeague.vue";
</script>

<style scoped></style>

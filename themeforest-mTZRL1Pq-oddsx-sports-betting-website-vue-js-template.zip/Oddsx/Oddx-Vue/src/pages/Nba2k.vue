<template>
  <TopNba2k />
 <UpCmingNba2k />
</template>

<script setup lang="ts">
import TopNba2k from "../components/Pages/Nba2k/TopNba2k.vue";
import UpCmingNba2k from "../components/Pages/Nba2k/UpCmingNba2k.vue";
</script>

<style scoped></style>

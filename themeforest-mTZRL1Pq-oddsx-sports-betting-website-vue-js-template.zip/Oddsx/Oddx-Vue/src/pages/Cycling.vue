<template>
  <div>
    <OutRightsPolitics />
    <TourFranceWinner />
    <ParisRoubaixWinner />
    <TourFlandersWinner />
  </div>
</template>

<script setup lang="ts">
import OutRightsPolitics from "../components/Pages/Cycling/OutRightsPolitics.vue";
import ParisRoubaixWinner from "../components/Pages/Cycling/ParisRoubaixWinner.vue";
import TourFlandersWinner from "../components/Pages/Cycling/TourFlandersWinner.vue";
import TourFranceWinner from "../components/Pages/Cycling/TourFranceWinner.vue";
</script>

<style scoped></style>

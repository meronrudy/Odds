<template>
  <div>
    <TopBandy />
    <UpCommingBandy />
  </div>
</template>

<script setup lang="ts">
import TopBandy from "../components/Pages/Bandy/TopBandy.vue";
import UpCommingBandy from "../components/Pages/Bandy/UpCommingBandy.vue";
</script>

<style scoped></style>

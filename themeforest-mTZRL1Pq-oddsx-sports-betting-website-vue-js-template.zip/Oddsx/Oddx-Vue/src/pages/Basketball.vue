<template>
  <div>
    <TopBasketball />
    <BasketballLive />
    <UpCmingBasketball />
  </div>
</template>

<script setup lang="ts">
import TopBasketball from "../components/Pages/Basketball/TopBasketball.vue";
import BasketballLive from "../components/Pages/Basketball/BasketballLive.vue";
import UpCmingBasketball from "../components/Pages/Basketball/UpCmingBasketball.vue";
</script>

<style scoped></style>

<template>
  <UpCommingAmericanFootball />
</template>

<script setup lang="ts">
import UpCommingAmericanFootball from "../components/Pages/AmericanFootball/UpCommingAmericanFootball.vue";
</script>

<style scoped></style>

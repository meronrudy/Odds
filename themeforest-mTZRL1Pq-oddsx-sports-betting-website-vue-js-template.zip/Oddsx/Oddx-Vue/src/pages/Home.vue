<template>
  <div>    
    <HeroSlider />
    <HeroMatches />
    <LiveMatches />
    <MiddleSlider />
    <UpCommingEvents />
  </div>
</template>

<script setup lang="ts">
import HeroMatches from "../components/Pages/Home/HeroMatches.vue";
import HeroSlider from "../components/Pages/Home/HeroSlider.vue";
import LiveMatches from "../components/Pages/Home/LiveMatches.vue";
import MiddleSlider from "../components/Pages/Home/MiddleSlider.vue";
import UpCommingEvents from "../components/Pages/Home/UpCommingEvents.vue";
</script>

<style scoped></style>

<template>
  <UkPolitics />
  <NextPresident />
  <OverAllMajority />
  <UsPresidentialElection />
  <NextLondon />
  <PartyLeade />
  <DemocraticPresidential />
  <PrimeMinister />
  <MinisterAfterElection />
  <AfterElection />
</template>

<script setup lang="ts">
import NextPresident from "../components/Pages/Specials/NextPresident.vue";
import OverAllMajority from "../components/Pages/Specials/OverAllMajority.vue";
import UkPolitics from "../components/Pages/Specials/UkPolitics.vue";
import NextLondon from "../components/Pages/Specials/NextLondon.vue";
import UsPresidentialElection from "../components/Pages/Specials/UsPresidentialElection.vue";
import PartyLeade from "../components/Pages/Specials/PartyLeade.vue";
import DemocraticPresidential from "../components/Pages/Specials/DemocraticPresidential.vue";
import PrimeMinister from "../components/Pages/Specials/PrimeMinister.vue";
import MinisterAfterElection from "../components/Pages/Specials/MinisterAfterElection.vue";
import AfterElection from "../components/Pages/Specials/AfterElection.vue";
</script>

<style scoped></style>

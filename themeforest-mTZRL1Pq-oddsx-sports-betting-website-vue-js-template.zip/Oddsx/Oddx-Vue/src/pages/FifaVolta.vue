<template>
  <div>
    <TopFifaVolta />
    <FifaVoltaLive/>
  </div>
</template>

<script setup lang="ts">
import FifaVoltaLive from '../components/Pages/FifaVolta/FifaVoltaLive.vue';
import TopFifaVolta from '../components/Pages/FifaVolta/TopFifaVolta.vue';
</script>

<style scoped></style>

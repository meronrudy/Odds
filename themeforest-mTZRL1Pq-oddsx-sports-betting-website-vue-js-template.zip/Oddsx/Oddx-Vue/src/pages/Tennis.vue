<template>
  <TopTennis />
  <TennisLive />
  <UpCmingTennis />
</template>

<script setup lang="ts">
import TennisLive from '../components/Pages/Tennis/TennisLive.vue';
import TopTennis from '../components/Pages/Tennis/TopTennis.vue';
import UpCmingTennis from '../components/Pages/Tennis/UpCmingTennis.vue';
</script>

<style scoped></style>

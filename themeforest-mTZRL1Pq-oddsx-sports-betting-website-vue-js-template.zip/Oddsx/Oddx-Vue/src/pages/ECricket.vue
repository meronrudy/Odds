<template>
  <TopEcricket />
  <EcricketLive />
  <UpCmingEcricket/>
</template>

<script setup lang="ts">
import EcricketLive from '../components/Pages/eCricket/EcricketLive.vue';
import TopEcricket from '../components/Pages/eCricket/TopEcricket.vue';
import UpCmingEcricket from '../components/Pages/eCricket/UpCmingEcricket.vue';
</script>

<style scoped></style>

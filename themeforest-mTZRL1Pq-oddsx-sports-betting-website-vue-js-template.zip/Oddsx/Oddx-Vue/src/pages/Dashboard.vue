<template>
  <DashBoard />
</template>

<script setup lang="ts">
import DashBoard from '../components/Pages/Dashboard/DashBoard.vue';
</script>

<style scoped></style>

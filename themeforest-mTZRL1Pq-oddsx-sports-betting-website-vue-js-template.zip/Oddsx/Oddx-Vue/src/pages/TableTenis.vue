<template>
  <TopTableTennis />
  <UpCmingTableTennis />
</template>

<script setup lang="ts">
import TopTableTennis from '../components/Pages/TableTennis/TopTableTennis.vue';
import UpCmingTableTennis from '../components/Pages/TableTennis/UpCmingTableTennis.vue';
</script>

<style scoped></style>

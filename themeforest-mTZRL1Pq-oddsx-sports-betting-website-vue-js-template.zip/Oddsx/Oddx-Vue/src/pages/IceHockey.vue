<template>
  <TopIceHockey />
  <UpCmingIceHockey />
</template>

<script setup lang="ts">
import TopIceHockey from '../components/Pages/IceHockey/TopIceHockey.vue';
import UpCmingIceHockey from '../components/Pages/IceHockey/UpCmingIceHockey.vue';
</script>

<style scoped></style>

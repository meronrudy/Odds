<template>
  <Hungary />
  <International />
  <LenChampionsLeague />
  <WomenGroupD />
  <WomenGroupWinner />
  <LenChampionsWinner />
  <WomenGroupWinner />
  <WomenGroupAWinner />
  <WomenGroupCWinner />
  <WomenGroupBWinner />
  <WomenGroupDWinner />
  <LenChampionsLeague />
  <OutRightItaly />
</template>

<script setup lang="ts">
import Hungary from "../components/Pages/WaterPolo/Hungary.vue";
import International from "../components/Pages/WaterPolo/International.vue";
import LenChampionsLeague from "../components/Pages/WaterPolo/LenChampionsLeague.vue";
import OutRightItaly from "../components/Pages/WaterPolo/OutRightItaly.vue";
import WomenGroupAWinner from "../components/Pages/WaterPolo/WomenGroupAWinner.vue";
import WomenGroupBWinner from "../components/Pages/WaterPolo/WomenGroupBWinner.vue";
import WomenGroupCWinner from "../components/Pages/WaterPolo/WomenGroupCWinner.vue";
import WomenGroupDWinner from "../components/Pages/WaterPolo/WomenGroupDWinner.vue";
import WomenGroupD from "../components/Pages/WaterPolo/WomenGroupD.vue";
import WomenGroupWinner from "../components/Pages/WaterPolo/WomenGroupWinner.vue";
import LenChampionsWinner from "../components/Pages/WaterPolo/LenChampionsWinner.vue";
</script>

<style scoped></style>

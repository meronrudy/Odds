<template>
  <div>
    <TopFutsal />
    <FutsalLive />
    <UpCmingFutsal />
  </div>
</template>

<script setup lang="ts">
import FutsalLive from '../components/Pages/Futsal/FutsalLive.vue';
import TopFutsal from '../components/Pages/Futsal/TopFutsal.vue';
import UpCmingFutsal from '../components/Pages/Futsal/UpCmingFutsal.vue';
</script>

<style scoped></style>

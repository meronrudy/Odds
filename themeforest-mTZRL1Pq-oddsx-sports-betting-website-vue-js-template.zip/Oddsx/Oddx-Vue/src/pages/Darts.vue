<template>
  <div>
    <TopDarts />
    <UpcmingDarts />
  </div>
</template>

<script setup lang="ts">
import TopDarts from '../components/Pages/Darts/TopDarts.vue';
import UpcmingDarts from '../components/Pages/Darts/UpcmingDarts.vue';
</script>

<style scoped></style>

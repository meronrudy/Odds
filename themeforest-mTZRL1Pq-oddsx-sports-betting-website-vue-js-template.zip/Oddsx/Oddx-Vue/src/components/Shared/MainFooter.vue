<template>
  <footer class="footer_section pt-10 pt-md-15 pt-lg-20 p2-bg pb-12 pb-md-0">
    <div class="container-fluid">
      <div class="row mb-10 mb-md-15 mb-lg-20">
        <div class="col-12">
          <div class="footer_section__main">
            <div class="row gy-8">
              <div class="col-sm-6 col-md-4 col-lg-4 col-xl-2 col-xxl-2">
                <div class="footer_section__sports">
                  <h4 class="mb-5 mb-md-6">Sports</h4>
                  <ul class="d-flex flex-column gap-5">
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Sports
                      </router-link>
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="/floorball"
                        >Live Betting</router-link
                      >
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Virtuals
                      </router-link>
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Football
                      </router-link>
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="/basketball"
                        >Basketball</router-link
                      >
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <span class="rtawin">
                        <IconArrowBadgeRight size="20" />
                      </span>
                      <router-link class="fs-ten n4-color" to="/ice-hockey"
                        >Ice Hockey</router-link
                      >
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-sm-6 col-md-4 col-lg-4 col-xl-2 col-xxl-2">
                <div class="footer_section__promotions">
                  <h4 class="mb-5 mb-md-6">Promotions</h4>
                  <ul class="d-flex flex-column gap-5">
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="/promotions"
                        >Sports Promotions</router-link
                      >
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Tournaments
                      </router-link>
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Achievements
                      </router-link>
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Bonus Shop
                      </router-link>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-sm-6 col-md-4 col-lg-4 col-xl-3 col-xxl-2">
                <div class="footer_section__help">
                  <h4 class="mb-5 mb-md-6">Help</h4>
                  <ul class="d-flex flex-column gap-5">
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Help
                      </router-link>
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Bet Slip Check
                      </router-link>
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >DepositsLink/ Withdrawals</router-link
                      >
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Sports results
                      </router-link>
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Sports stats
                      </router-link>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-sm-6 col-md-4 col-lg-6 col-xl-4 col-xxl-3">
                <div class="footer_section__security">
                  <h4 class="mb-5 mb-md-6">Security and Privacy</h4>
                  <ul class="d-flex flex-column gap-5">
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Privacy Policy
                      </router-link>
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Terms aLinkd Conditions</router-link
                      >
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Cookie Policy
                      </router-link>
                    </li>
                    <li class="iconstyle d-flex align-items-center">
                      <IconArrowBadgeRight size="20" class="rtawin" />
                      <router-link class="fs-ten n4-color" to="#"
                        >Sports results
                      </router-link>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-sm-8 col-md-5 col-lg-6 col-xxl-3">
                <div class="footer_section__community">
                  <h4 class="mb-5 mb-md-6">Join our Community</h4>
                  <ul class="d-flex align-items-center flex-wrap gap-5">
                    <li>
                      <router-link
                        class="footer_section__community-sitem n4-coloLink"
                        to="#"
                      >
                        <IconBrandTelegram class="fs-three footericon" />
                      </router-link>
                    </li>
                    <li>
                      <router-link
                        class="footer_section__community-sitem n4-coloLink"
                        to="#"
                      >
                        <IconBrandGithubFilled class="fs-three footericon" />
                      </router-link>
                    </li>
                    <li>
                      <router-link
                        class="footer_section__community-sitem n4-coloLink"
                        to="#"
                      >
                        <IconBrandBehance class="fs-three footericon" />
                      </router-link>
                    </li>
                    <li>
                      <router-link
                        class="footer_section__community-sitem n4-coloLink"
                        to="#"
                      >
                        <IconBrandFacebookFilled class="fs-three footericon" />
                      </router-link>
                    </li>
                    <li>
                      <router-link
                        class="footer_section__community-sitem n4-coloLink"
                        to="#"
                      >
                        <IconBrandDiscordFilled class="fs-three footericon" />
                      </router-link>
                    </li>
                    <li>
                      <router-link
                        class="footer_section__community-sitem n4-coloLink"
                        to="#"
                      >
                        <IconCurrencyBitcoin class="fs-three bitcoin" />
                      </router-link>
                    </li>
                    <li>
                      <router-link
                        class="footer_section__community-sitem n4-coloLink"
                        to="#"
                      >
                        <IconBrandInstagram class="fs-three footericon" />
                      </router-link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-12 px-0 mx-0">
          <div class="brand-slider n6-bg pt-7 pb-7">
            <div
              class="footer_section__slider swiper-wrapper d-flex align-items-center"
            >
              <Swiper
                class="slider_hero"
                :loop="true"
                :speed="2000"
                :autoplay="{
                  delay: 0,
                }"
                :modules="[Autoplay]"
                :breakpoints="{
                  0: {
                    slidesPerView: 3,
                    spaceBetween: 5,
                  },
                  480: {
                    slidesPerView: 4,
                    spaceBetween: 10,
                  },
                  575: {
                    slidesPerView: 5,
                    spaceBetween: 20,
                  },
                  768: {
                    slidesPerView: 7,
                    spaceBetween: 20,
                  },
                  991: {
                    slidesPerView: 8,
                    spaceBetween: 20,
                  },
                  1199: {
                    slidesPerView: 10,
                    spaceBetween: 20,
                  },
                  1499: {
                    slidesPerView: 13,
                    spaceBetween: 24,
                  },
                  1799: {
                    slidesPerView: 15,
                    spaceBetween: 24,
                  },
                }"
              >
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img width="{104}" height="{30}" :src="visa" alt="Brand" />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      width="{120}"
                      height="{30}"
                      :src="netent"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      width="{39}"
                      height="{30}"
                      :src="masterCard"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img width="{82}" height="{29}" :src="skrill" alt="Brand" />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      width="{50}"
                      height="{30}"
                      :src="meastro"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      :src="webmoney"
                      width="{117}"
                      height="{30}"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      :src="neteller"
                      width="{178}"
                      height="{30}"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img :src="debit" width="{66}" height="{30}" alt="Brand" />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      :src="pragmathic"
                      width="{97}"
                      height="{32}"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img :src="play" width="{84}" height="{32}" alt="Brand" />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      :src="gamomat"
                      width="{100}"
                      height="{32}"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      :src="paysafecard"
                      width="{180}"
                      height="{30}"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      width="{120}"
                      height="{30}"
                      :src="netent"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      width="{39}"
                      height="{30}"
                      :src="masterCard"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img width="{82}" height="{29}" :src="skrill" alt="Brand" />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      width="{50}"
                      height="{30}"
                      :src="meastro"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      :src="webmoney"
                      width="{117}"
                      height="{30}"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      :src="neteller"
                      width="{178}"
                      height="{30}"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img :src="debit" width="{66}" height="{30}" alt="Brand" />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      :src="pragmathic"
                      width="{97}"
                      height="{32}"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img :src="play" width="{84}" height="{32}" alt="Brand" />
                  </div>
                </swiper-slide>
                <swiper-slide>
                  <div class="footer_section__slider-brand swiper-slide px-4">
                    <img
                      :src="gamomat"
                      width="{100}"
                      height="{32}"
                      alt="Brand"
                    />
                  </div>
                </swiper-slide>
              </Swiper>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>

<script setup lang="ts">
import { Swiper, SwiperSlide } from "swiper/vue";
import "swiper/css";
import "swiper/css/pagination";
import { Autoplay } from "swiper/modules";
import {
  IconArrowBadgeRight,
  IconBrandBehance,
  IconBrandDiscordFilled,
  IconBrandFacebookFilled,
  IconBrandGithubFilled,
  IconBrandInstagram,
  IconBrandTelegram,
  IconCurrencyBitcoin,
} from "@tabler/icons-vue";

import visa from "@/assets/images/visa-card.png";
import netent from "@/assets/images/icon/netent.png";
import masterCard from "@/assets/images/icon/mastercard.png";
import skrill from "@/assets/images/icon/skrill.png";
import neteller from "@/assets/images/icon/neteller.png";
import gamomat from "@/assets/images/icon/gamomat.png";
import play from "@/assets/images/icon/play-go.png";
import pragmathic from "@/assets/images/icon/pragmathic-play.png";
import debit from "@/assets/images/icon/debit.png";
import webmoney from "@/assets/images/icon/webmoney.png";
import paysafecard from "@/assets/images/icon/paysafecard.png";
import meastro from "@/assets/images/icon/maestro.png";
</script>

<style scoped></style>
